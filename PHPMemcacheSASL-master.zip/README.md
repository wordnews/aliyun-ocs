# MemcacheSASL

A PHP Memcache client with [binary
protocol](http://code.google.com/p/memcached/wiki/BinaryProtocolRevamped) and
[SASL](http://code.google.com/p/memcached/wiki/SASLAuthProtocol) support.

You can find documentation on the PHP Memcached class
[here](http://php.net/manual/en/class.memcached.php).

