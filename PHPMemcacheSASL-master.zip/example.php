<?php

include('MemcacheSASL.php');

$m = new MemcacheSASL;

var_dump($m->delete('test'));
echo '<br/>';
var_dump($m->get('test'));

echo '<br/>';

$arr = [
    'uid' => 1,
    'username' => '小米'
];

//var_dump($m->set('arr', $arr));

echo '<hr/>';

var_dump($m->get('arr'));
//$m->delete('test');

